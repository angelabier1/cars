$(function() {


    $(function() {
        var VIN_CLASSNAME = 'vin';
        var LIST_VIN = $('dt:contains("VIN:") + dd');
        var DETAIL_VIN = $("span:contains('VIN:') + strong");
        DETAIL_VIN.addClass(VIN_CLASSNAME);
        LIST_VIN.addClass(VIN_CLASSNAME);
    });

    $(function() {$('.vin').on('click', function() {
        vinNumber = $(this).text();
        if (vinNumber) {
            window.open('http://www.saratogahonda.com/ajax-autocheck?vin=' + vinNumber);
        }
    });
  });
});
